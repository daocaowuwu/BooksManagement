package com.daocaowu.service.impl;

import com.daocaowu.domain.Book;
import com.daocaowu.domain.Borrow;
import com.daocaowu.mappers.BookMapper;
import com.daocaowu.mappers.BorrowMapper;
import com.daocaowu.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookServiceImpl implements BookService {
    @Autowired
    private BookMapper bookMapper;
    @Autowired
    private BorrowMapper borrowMapper;

    @Override
    public Integer BorrowBook(String userid, String bookid) {
        return bookMapper.insertBorrow(userid,bookid);
    }

    @Override
    public Integer BorrowBookState(String bookid) {
        return bookMapper.updateBookStateBorrow(bookid);
    }

    @Override
    public Integer UpdateBookStateReturn(String bookid) {
        return bookMapper.updateBookStateReturn(bookid);
    }

    @Override
    public Integer SelectBorrow(String userid, String bookid) {
        return bookMapper.selectBorrow(userid, bookid);
    }

    @Override
    public String SelectBookStateReturn(String bookid) {
        return bookMapper.selectBookStateReturn(bookid);
    }

    @Override
    public Integer InsertReturn(String userid, String bookid) {
        return bookMapper.insertReturn(userid, bookid);
    }

    @Override
    public List<Book> SelectBookList(String pageNum, String pageSize, String bookid, String bookname, String booksort) {
        return bookMapper.selectBookList(pageNum,pageSize,bookid,bookname,booksort);
    }

    @Override
    public Book SelectBookById(String bookid) {
        return bookMapper.selectBookById(bookid);
    }

    @Override
    public Integer InsertBook(Book book) {
        return bookMapper.insertBook(book);
    }

    @Override
    public Integer UpdateBook(Book book) {
        return bookMapper.updateBook(book);
    }

    @Override
    public Integer DeleteBookById(String bookid) {
        return bookMapper.deleteBookByBookid(bookid);
    }

    @Override
    public Borrow SelectBorrowByUserid(String userid,String bookid) {
        return borrowMapper.selectBorrowByUserid(userid,bookid);
    }

    @Override
    public Integer UpdateBorrow(Borrow borrow) {
        return borrowMapper.updateBorrow(borrow);
    }

}
