package com.daocaowu.service;

import com.daocaowu.domain.Borrow;
import com.daocaowu.domain.Reader;
import com.daocaowu.domain.Result;
import com.daocaowu.domain.User;

import java.util.List;

public interface UserService {

    public User UserLogin(String userid,String password,String rememberMe);
    public int UserProfile(User user);
    public List<Reader> ReaderDetail(String userid,String pageNum, String pageSize);
    public List<User> SelectReaderList(String pageNum, String pageSize,String  userid,String username);
    public List<User> SelectManagerList(String pageNum, String pageSize,String  userid,String username);
    public User SelectUserByUserid(String userid);
    public Integer InsertUser(User user);
    public Integer deleteUserByUserid(String userid);

    public List<Borrow> readerBorrow(String userid, String pageNum, String pageSize);
}
