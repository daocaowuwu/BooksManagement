package com.daocaowu.service.impl;

import com.daocaowu.domain.Borrow;
import com.daocaowu.domain.Reader;
import com.daocaowu.mappers.ReaderMapper;
import com.daocaowu.mappers.UserMapper;
import com.daocaowu.domain.User;
import com.daocaowu.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;
    @Autowired
    private ReaderMapper readerMapper;


    @Override
    public User UserLogin(String userid,String password,String rememberMe) {
        return userMapper.selectLoginUser(userid,password,rememberMe);
    }

    @Override
    public int UserProfile(User user) {
        return userMapper.UpdateUserInfo(user);
    }

    @Override
    public List<Reader> ReaderDetail(String userid,String pageNum, String pageSize) {
        return readerMapper.selectReaderByUserid(userid,pageNum,pageSize);
    }

    @Override
    public List<User> SelectReaderList(String pageNum, String pageSize,String  userid,String username) {
        return userMapper.selectReaderList(pageNum, pageSize,userid,username);
    }

    @Override
    public List<User> SelectManagerList(String pageNum, String pageSize,String  userid,String username) {
        return userMapper.selectManagerList(pageNum, pageSize,userid,username);
    }

    @Override
    public User SelectUserByUserid(String userid) {
        return userMapper.selectUserByUserid(userid);
    }

    @Override
    public Integer InsertUser(User user) {
        return userMapper.insertUser(user);
    }

    @Override
    public Integer deleteUserByUserid(String userid) {
        return userMapper.deleteUserByUserid(userid);
    }

    @Override
    public List<Borrow> readerBorrow(String userid, String pageNum, String pageSize) {
        return userMapper.readerBorrow(userid, pageNum, pageSize);
    }


}
