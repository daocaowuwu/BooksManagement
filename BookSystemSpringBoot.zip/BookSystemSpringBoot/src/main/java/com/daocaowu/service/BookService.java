package com.daocaowu.service;

import com.daocaowu.domain.Book;
import com.daocaowu.domain.Borrow;
import com.daocaowu.domain.Result;

import java.util.List;

public interface BookService {
    public Integer BorrowBook(String userid, String bookid);
    public Integer BorrowBookState(String bookid);

    public Integer UpdateBookStateReturn(String bookid);
    public Integer SelectBorrow(String userid, String bookid);
    public String SelectBookStateReturn(String bookid);
    public Integer InsertReturn(String userid, String bookid);

    public List<Book> SelectBookList(String pageNum, String pageSize, String  bookid, String bookname, String booksort);
    public Book SelectBookById(String bookid);
    public Integer InsertBook(Book book);
    public Integer UpdateBook(Book book);
    public Integer DeleteBookById(String bookid);

    public Borrow SelectBorrowByUserid(String userid,String bookid);
    public Integer UpdateBorrow(Borrow borrow);
}
