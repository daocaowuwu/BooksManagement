package com.daocaowu.contorller;

import com.daocaowu.domain.Book;
import com.daocaowu.domain.Borrow;
import com.daocaowu.domain.Code;
import com.daocaowu.domain.Result;
import com.daocaowu.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/book")
public class BookController {
    @Autowired
    BookService bookService;

    @RequestMapping("/borrow")
    @ResponseBody
    public Result BookBorrow(String userid,String bookid){
        Integer borrowNum=bookService.BorrowBookState(bookid);
        if(borrowNum>0)
        {
            if(bookService.BorrowBook(userid, bookid)>0)
            return new Result(Code.SUCCESS,null,"借书成功");
        }
            return new Result(Code.FAIL,null,"借书失败");
    }

    @RequestMapping("/return")
    @ResponseBody
    public Result BookReturn(String userid,String bookid) {
        Integer selectBorrowNum=bookService.SelectBorrow(userid, bookid);
        if(selectBorrowNum>0)
        {
            if(bookService.SelectBookStateReturn(bookid).equals("0"))
            {
                if(bookService.InsertReturn(userid, bookid)>0) {
                    if(bookService.UpdateBookStateReturn(bookid)>0)
                    return new Result(Code.SUCCESS, null, "还书成功！");
                }
            }
        }
        return new Result(Code.FAIL,null,"还书失败！");
    }

    @RequestMapping("/list")
    @ResponseBody
    public Result SelectBooksList(String pageNum, String pageSize,String  bookid,String bookname,String booksort){
        List<Book> bookListtotal=bookService.SelectBookList("0","10000",bookid,bookname,booksort);
        List<Book> bookList=bookService.SelectBookList(pageNum,pageSize,bookid,bookname,booksort);
        if(bookList.size()>0){
            System.out.println(bookList+"   "+String.valueOf(bookListtotal.size()));
            return new Result(Code.SUCCESS,bookList,String.valueOf(bookListtotal.size()));
        }
        return new Result(Code.FAIL,null,"查询失败");
    }

    @RequestMapping(value = "/detail/{bookid}",method = RequestMethod.GET)
    @ResponseBody
    public Result BookDetail(@PathVariable String bookid){
        Book book=bookService.SelectBookById(bookid);
        System.out.println(book);
        Integer code=(book!=null?Code.SUCCESS:Code.FAIL);
        if(code==Code.SUCCESS)
        {
            return new Result(code,book,"查询成功");
        }
        return new Result(code,null,"查询失败");
    }

    @RequestMapping(value = "/add",method = RequestMethod.POST)
    @ResponseBody
    public Result BookAdd(@RequestBody Book book){
        Integer addNum=bookService.InsertBook(book);
        Integer code=addNum>0?Code.SUCCESS:Code.FAIL;
        String msg=addNum>0?"新增成功":"新增失败";
        return new Result(code,null,msg);
    }

    @RequestMapping(value = "/update",method = RequestMethod.PUT)
    @ResponseBody
    public Result BookUpdate(@RequestBody Book book){
        Integer updateNum=bookService.UpdateBook(book);
        Integer code=updateNum>0?Code.SUCCESS:Code.FAIL;
        String msg=updateNum>0?"更新成功":"更新失败";
        return new Result(code,null,msg);
    }

    @RequestMapping(value = "/delete/{bookid}",method = RequestMethod.DELETE)
    @ResponseBody
    public Result BookDelete(@PathVariable String bookid){
        Integer deleteNum=bookService.DeleteBookById(bookid);
        Integer code=deleteNum>0?Code.SUCCESS:Code.FAIL;
        String msg=deleteNum>0?"删除成功":"删除失败,存在借阅信息！";
        System.out.println(msg);
        return new Result(code,null,msg);
    }


    @RequestMapping("/borrowinfo")
    @ResponseBody
    public Result BorrowInfo(String userid,String bookid){
        Borrow borrow = bookService.SelectBorrowByUserid(userid,bookid);
        System.out.println(borrow);
        if(borrow!=null){
            return new Result(Code.SUCCESS,borrow,"查询成功");
        }
        return new Result(Code.FAIL,null,"失败！");
    }

    @RequestMapping(value = "/borrowupdate",method = RequestMethod.PUT)
    @ResponseBody
    public Result BorrowUpdate(@RequestBody Borrow borrow){
        Integer updateNum=bookService.UpdateBorrow(borrow);
        Integer code=updateNum>0?Code.SUCCESS:Code.FAIL;
        String msg=updateNum>0?"更新成功":"更新失败";
        return new Result(code,null,msg);
    }
}
