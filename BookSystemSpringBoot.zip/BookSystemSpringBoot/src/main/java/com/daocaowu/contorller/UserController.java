package com.daocaowu.contorller;

import com.daocaowu.domain.*;
import com.daocaowu.service.UserService;
import com.daocaowu.utils.MD5Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/system")
public class UserController {
    @Autowired
    private UserService userService;
    @Autowired
    private MD5Util md5Util;

    @RequestMapping("/userlogin")
    @ResponseBody
    public Result LoginResult(String userid,String password,String rememberMe) throws Exception {
        password=md5Util.md5Encode(password);
        User user=userService.UserLogin(userid,password,rememberMe);
        System.out.println(user);
        Integer code=user!=null? Code.SUCCESS:Code.FAIL;
        String msg=user!=null?"登陆成功":"登陆失败";
        System.out.println(msg);
        if(user!=null)
        {user.setPassword(md5Util.md5Encode(password));}
        return new Result(code,user,msg);
    }

    @PutMapping(value="/userprofile",produces = "application/json;charset=UTF-8")
    @ResponseBody
    public Result UserProfile(@RequestBody User user) throws Exception {
        //System.out.println(user);
        String password=user.getPassword();
        user.setPassword(md5Util.md5Encode(password));
        Integer updateNum=userService.UserProfile(user);
        Integer code=updateNum>0? Code.SUCCESS:Code.FAIL;
        String msg=updateNum>0?"修改成功":"修改失败";

        return new Result(code, null,msg);
    }

    @RequestMapping("/reader")
    @ResponseBody
    public Result ReaderDetail(String userid,String pageNum, String pageSize){
        List<Reader> readertotal=userService.ReaderDetail(userid,"0","10000");
        List<Reader> reader=userService.ReaderDetail(userid,pageNum,pageSize);
        System.out.println(reader);
        Integer code=reader!=null?Code.SUCCESS:Code.FAIL;
        String msg=reader!=null?String.valueOf(readertotal.size()):"查询读者详细信息失败！";
        return new Result(code,reader,msg);
    }

    @RequestMapping("/readerslist")
    @ResponseBody
    public Result UserList(String pageNum, String pageSize,String  userid,String username){
        List<User> userstotal=userService.SelectReaderList("0", "10000",userid,username);
        List<User> users=userService.SelectReaderList(pageNum, pageSize,userid,username);
        System.out.println(users);
        String msg=users!=null?String.valueOf(userstotal.size()):"查询信息失败！";
        if(users.size()>0)
            return new Result(Code.SUCCESS,users,msg);
        return new Result(Code.FAIL,null,msg);
    }

    @RequestMapping(value = "/readerdetail/{userid}",method = RequestMethod.GET)
    @ResponseBody
    public Result UserInfo(@PathVariable String userid) throws Exception {
        User user=userService.SelectUserByUserid(userid);
        String password=user.getPassword();
        user.setPassword(md5Util.md5Encode(password));
        System.out.println(user);
        Integer code=user!=null?Code.SUCCESS:Code.FAIL;
        String msg=user!=null?"查询成功":"查询失败！";
        return new Result(code,user,msg);
    }

    @RequestMapping(value = "/readeradd",method = RequestMethod.POST)
    @ResponseBody
    public Result BookAdd(@RequestBody User user) throws Exception {
        String password=user.getPassword();
        user.setPassword(md5Util.md5Encode(password));
        Integer addNum=userService.InsertUser(user);
        Integer code=addNum>0?Code.SUCCESS:Code.FAIL;
        String msg=addNum>0?"新增成功":"新增失败";
        return new Result(code,null,msg);
    }

    @RequestMapping(value = "/readerdelete/{userid}",method = RequestMethod.DELETE)
    @ResponseBody
    public Result ReaderDelete(@PathVariable String userid){
        Integer deleteNum=userService.deleteUserByUserid(userid);
        Integer code=deleteNum>0?Code.SUCCESS:Code.FAIL;
        String msg=deleteNum>0?"删除成功":"删除失败,该用户有借阅记录！";
        System.out.println(msg);
        return new Result(code,null,msg);
    }

    @RequestMapping("/managerslist")
    @ResponseBody
    public Result SelectManagersList(String pageNum, String pageSize,String  userid,String username){
        List<User> userListtotal=userService.SelectManagerList("0", "10000",userid,username);
        List<User> userList=userService.SelectManagerList(pageNum, pageSize,userid,username);
        if(userList.size()>0){
            System.out.println(userList+"   "+String.valueOf(userListtotal.size()));
            return new Result(Code.SUCCESS,userList,String.valueOf(userListtotal.size()));
        }
        return new Result(Code.FAIL,null,"查询失败");
    }

    @RequestMapping("/readerborrow")
    @ResponseBody
    public Result ReaderBorrow(String userid,String pageNum, String pageSize){
        List<Borrow> readertotal=userService.readerBorrow(userid,"0","100000");
        List<Borrow> reader=userService.readerBorrow(userid,pageNum,pageSize);
        System.out.println(reader);
        Integer code=reader!=null?Code.SUCCESS:Code.FAIL;
        String msg=reader!=null?String.valueOf(readertotal.size()):"查询读者详细信息失败！";
        return new Result(code,reader,msg);
    }
}
