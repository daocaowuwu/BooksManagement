package com.daocaowu.mappers;

import com.daocaowu.domain.Reader;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface ReaderMapper {

    @Select("Select * from" +
            "(SELECT DISTINCT C.*,D.days, "+
            "(SELECT count(*)  FROM "+
            "(SELECT tb_borrow.userid,TIMESTAMPDIFF(DAY,tb_borrow.borrowtime,CURRENT_TIMESTAMP) FROM tb_borrow "+
            "WHERE (tb_borrow.userid,tb_borrow.bookid) NOT in "+
            "(SELECT userid,bookid from tb_return)) as E "+
            "WHERE E.userid=D.userid) borrowed FROM "+
            "(SELECT tb_borrow.userid,tb_borrow.bookid,TIMESTAMPDIFF(DAY,tb_borrow.borrowtime,CURRENT_TIMESTAMP) days FROM tb_borrow "+
            "WHERE (tb_borrow.userid,tb_borrow.bookid) NOT in  "+
            "(SELECT userid,bookid from tb_return) ) as D, "+
            "(SELECT user.*,B.bookid from user, "+
            "(SELECT A.userid,A.bookid FROM "+
            "(SELECT tb_borrow.userid,tb_borrow.bookid,TIMESTAMPDIFF(DAY,tb_borrow.borrowtime,CURRENT_TIMESTAMP) FROM tb_borrow "+
            "WHERE (tb_borrow.userid,tb_borrow.bookid) NOT in  "+
            "(SELECT userid,bookid from tb_return) ) as A  "+
            ") as B "+
            "WHERE user.userid=B.userid "+
            ") as C "+
            "WHERE C.userid=D.userid AND C.bookid=D.bookid) as G "+
            "Where IF ('${userid}'='',1=1,userid=#{userid})  order by days desc limit ${pageNum},${pageSize}")
    public List<Reader> selectReaderByUserid(String userid,String pageNum, String pageSize);
}
