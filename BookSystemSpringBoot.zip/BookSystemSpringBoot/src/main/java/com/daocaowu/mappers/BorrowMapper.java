package com.daocaowu.mappers;

import com.daocaowu.domain.Borrow;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface BorrowMapper {

    /**
     * 该用户已借未还信息
     * @param userid
     * @return
     */
    @Select("SELECT tb_borrow.userid,tb_borrow.bookid,tb_borrow.borrowtime FROM tb_borrow\n" +
            "WHERE (tb_borrow.userid,tb_borrow.bookid) NOT in \n" +
            "(SELECT userid,bookid from tb_return) AND userid=#{userid} AND bookid=#{bookid}")
    public Borrow selectBorrowByUserid(String userid,String bookid);

    @Update("update tb_borrow set borrowtime= "+
            "#{borrowtime} where userid=#{userid} and bookid=#{bookid}")
    public Integer updateBorrow(Borrow borrow);
}
