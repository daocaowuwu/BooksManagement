package com.daocaowu.mappers;

import com.daocaowu.domain.Book;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface BookMapper {

    //借书操作
    @Insert("INSERT INTO tb_borrow (userid,bookid) VALUES ('${userid}','${bookid}')")
    public Integer insertBorrow(String userid, String bookid);

    @Update("UPDATE book SET bookstate = '0' " +
            "WHERE bookid = '${bookid}' and bookstate='1'")
    public Integer updateBookStateBorrow(String bookid);


    //还书操作
    @Update("UPDATE book SET bookstate = '1' " +
            "WHERE bookid = '${bookid}' and bookstate='0'")
    public Integer updateBookStateReturn(String bookid);

//    已借未还才可以还！
    @Select("SELECT count(*) FROM " +
            "(SELECT tb_borrow.userid,tb_borrow.bookid FROM tb_borrow\n" +
            "WHERE (tb_borrow.userid,tb_borrow.bookid) NOT in \n" +
            "(SELECT userid,bookid from tb_return)\n" +
            ") AS A " +
            " WHERE A.userid='${userid}' AND A.bookid='${bookid}'")
    public Integer selectBorrow(String userid, String bookid);

    @Select("SELECT bookstate FROM book WHERE  bookid='${bookid}'")
    public String selectBookStateReturn(String bookid);

    @Insert("INSERT INTO tb_return (userid,bookid) VALUES ('${userid}','${bookid}')")
    public Integer insertReturn(String userid, String bookid);

    //图书信息查询
    public List<Book> selectBookList(String pageNum, String pageSize,String  bookid,String bookname,String booksort);

    @Select("select * from book where bookid='${bookid}'")
    public Book selectBookById(String bookid);

    public Integer insertBook(Book book);
    public Integer updateBook(Book book);
    public Integer deleteBookByBookid(String bookid);
}
