package com.daocaowu.mappers;

import com.daocaowu.domain.Borrow;
import com.daocaowu.domain.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface UserMapper {

    /**
     * 所有用户的登录验证及基本信息
     * @param  userid, password,rememberMe
     * @return 用户
     */
    @Select("select * from user where userid=#{userid} and password=#{password}")
    public User selectLoginUser(String userid,String password,String rememberMe);

    /**
     * 查询用户
     *
     * @param userid 用户主键
     * @return 用户
     */
    @Select("select * from user where userid=#{userid}")
    public User selectUserByUserid(String userid);

    public List<User> selectReaderList(String pageNum, String pageSize,String  userid,String username);

   public List<User> selectManagerList(String pageNum, String pageSize,String  userid,String username);

   @Select("SELECT * from\n" +
           "(SELECT tb_borrow.userid,tb_borrow.bookid,book.bookname,tb_borrow.borrowtime\n" +
           "FROM tb_borrow,book\n" +
           "WHERE book.bookid=tb_borrow.bookid and (tb_borrow.userid,tb_borrow.bookid) NOT in \n" +
           "(SELECT userid,bookid from tb_return)) A\n" +
           "WHERE A.userid=#{userid}")
    public List<Borrow> readerBorrow(String userid, String pageNum, String pageSize);


    /**
     * 新增用户
     *
     * @param user 用户
     * @return 结果
     */
    public int insertUser(User user);

    /**
     * 修改用户
     *
     * @param user 用户
     * @return 结果
     */
    public int UpdateUserInfo(User user);

    /**
     * 删除用户
     *
     * @param userid 用户主键
     * @return 结果
     */
    public int deleteUserByUserid(String userid);

    /**
     * 批量删除用户
     *
     * @param userids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteUserByUserids(String[] userids);
}
