package com.daocaowu.domain;


public class User
{
    private static final long serialVersionUID = 1L;

    /** 用户id */
    private String userid;

    /** 用户名 */
    private String username;

    /** 用户角色号 */
    private Long userrole;

    /** 年龄 */
    private Long age;

    /** 性别 */
    private Long sex;

    /** 手机号 */
    private String phone;

    /** 密码 */
    private String password;

    public void setUserid(String userid)
    {
        this.userid = userid;
    }

    public String getUserid()
    {
        return userid;
    }
    public void setUsername(String username)
    {
        this.username = username;
    }

    public String getUsername()
    {
        return username;
    }
    public void setUserrole(Long userrole)
    {
        this.userrole = userrole;
    }

    public Long getUserrole()
    {
        return userrole;
    }
    public void setAge(Long age)
    {
        this.age = age;
    }

    public Long getAge()
    {
        return age;
    }
    public void setSex(Long sex)
    {
        this.sex = sex;
    }

    public Long getSex()
    {
        return sex;
    }
    public void setPhone(String phone)
    {
        this.phone = phone;
    }

    public String getPhone()
    {
        return phone;
    }
    public void setPassword(String password)
    {
        this.password = password;
    }

    public String getPassword()
    {
        return password;
    }

    @Override
    public String toString() {
        return "{" +
                "userid:'" + userid + '\'' +
                ", username:'" + username + '\'' +
                ", userrole:" + userrole +
                ", age:" + age +
                ", sex:" + sex +
                ", phone:'" + phone + '\'' +
                ", password:'" + password + '\'' +
                '}';
    }
}

