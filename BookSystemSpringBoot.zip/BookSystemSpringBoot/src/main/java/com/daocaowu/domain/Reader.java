package com.daocaowu.domain;

public class Reader {
    /** 用户id */
    private String userid;

    /** 用户名 */
    private String username;

    /** 用户角色号 */
    private Long userrole;

    /** 年龄 */
    private Long age;

    /** 性别 */
    private Long sex;

    /** 手机号 */
    private String phone;

    /** 密码 */
    private String password;

    /** 已借数量 */
    private Long borrowed;

    /**  已借天数 */
    private Long days;

    private String bookid;

    public String getBookid() {
        return bookid;
    }

    public void setBookid(String bookid) {
        this.bookid = bookid;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Long getUserrole() {
        return userrole;
    }

    public void setUserrole(Long userrole) {
        this.userrole = userrole;
    }

    public Long getAge() {
        return age;
    }

    public void setAge(Long age) {
        this.age = age;
    }

    public Long getSex() {
        return sex;
    }

    public void setSex(Long sex) {
        this.sex = sex;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Long getBorrowed() {
        return borrowed;
    }

    public void setBorrowed(Long borrowed) {
        this.borrowed = borrowed;
    }

    public Long getDays() {
        return days;
    }

    public void setOverdue(Long days) {
        this.days = days;
    }

    @Override
    public String toString() {
        return "{" +
                "userid:'" + userid + '\'' +
                ", username:'" + username + '\'' +
                ", userrole:" + userrole +
                ", age:" + age +
                ", sex:" + sex +
                ", phone:'" + phone + '\'' +
                ", password:'" + password + '\'' +
                ", bookid:'" + bookid + '\'' +
                ", borrowed:" + borrowed +
                ", days:" + days +
                '}';
    }
}
