package com.daocaowu.domain;

public class Code {
    public static final Integer SUCCESS=200;
    public static final Integer FAIL=500;
}
