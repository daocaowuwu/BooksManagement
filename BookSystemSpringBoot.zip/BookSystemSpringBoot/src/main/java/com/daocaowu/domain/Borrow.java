package com.daocaowu.domain;

public class Borrow {

    private String userid;
    private String bookid;
    private String bookname;
    private String borrowtime;

    public String getBookname() {
        return bookname;
    }

    public void setBookname(String bookname) {
        this.bookname = bookname;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getBookid() {
        return bookid;
    }

    public void setBookid(String bookid) {
        this.bookid = bookid;
    }

    public String getBorrowtime() {
        return borrowtime;
    }

    public void setBorrowtime(String borrowtime) {
        this.borrowtime = borrowtime;
    }

    @Override
    public String toString() {
        return "{" +
                "userid:" + userid +
                ", bookid:" + bookid +
                ", bookname:" + bookname +
                ", borrowtime:'" + borrowtime + '\'' +
                '}';
    }
}
