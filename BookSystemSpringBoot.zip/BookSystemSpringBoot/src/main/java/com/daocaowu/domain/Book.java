package com.daocaowu.domain;

public class Book {
    private static final long serialVersionUID = 1L;

    /** 图书号 */
    private String bookid;

    /** 图书名称 */
    private String bookname;

    /** 图书状态 */
    private String bookstate;

    /** 图书种类 */
    private String booksort;

    /** 图书描述 */
    private String description;

    public void setBookid(String bookid)
    {
        this.bookid = bookid;
    }

    public String getBookid()
    {
        return bookid;
    }
    public void setBookname(String bookname)
    {
        this.bookname = bookname;
    }

    public String getBookname()
    {
        return bookname;
    }
    public void setBookstate(String bookstate)
    {
        this.bookstate = bookstate;
    }

    public String getBookstate()
    {
        return bookstate;
    }
    public void setBooksort(String booksort)
    {
        this.booksort = booksort;
    }

    public String getBooksort()
    {
        return booksort;
    }
    public void setDescription(String description)
    {
        this.description = description;
    }

    public String getDescription()
    {
        return description;
    }

    @Override
    public String toString() {
        return "{" +
                "bookid:'" + bookid + '\'' +
                ", bookname:'" + bookname + '\'' +
                ", bookstate:'" + bookstate + '\'' +
                ", booksort:'" + booksort + '\'' +
                ", description:'" + description + '\'' +
                '}';
    }
}
