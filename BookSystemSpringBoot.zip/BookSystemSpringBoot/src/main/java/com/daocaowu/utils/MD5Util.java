package com.daocaowu.utils;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import java.security.MessageDigest;

@Component
public class MD5Util {
    /***
     * MD5加密 生成32位md5码
     * @param inStr
     * @return 返回32位md5码
     */
    public static String md5Encode(String inStr) throws Exception {
        char[] a = inStr.toCharArray();
        for (int i = 0; i < a.length; i++){
            a[i] = (char) (a[i] ^ 't');
        }
        String s = new String(a);
        return s;
    }

    /**
     * 测试主函数
     * @param args
     * @throws Exception
     */
    public static void main(String args[]) throws Exception {
        String str = new String("123456");
        System.out.println("原始：" + str);
        str=md5Encode(str);
        System.out.println("MD5后：" + str);
        str=md5Encode(str);
        System.out.println("解密后：" + str);
    }
}