/*
Navicat MySQL Data Transfer

Source Server         : demo1
Source Server Version : 80028
Source Host           : localhost:3306
Source Database       : db_booksystem

Target Server Type    : MYSQL
Target Server Version : 80028
File Encoding         : 65001

Date: 2023-06-29 09:36:53
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for book
-- ----------------------------
DROP TABLE IF EXISTS `book`;
CREATE TABLE `book` (
  `bookid` char(8) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `bookname` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `bookstate` char(1) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '1' COMMENT '图书状态',
  `booksort` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '未知' COMMENT '图书种类',
  `description` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL COMMENT '图书描述',
  PRIMARY KEY (`bookid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- ----------------------------
-- Records of book
-- ----------------------------
INSERT INTO `book` VALUES ('A0000001', '小红帽', '0', '童话故事', null);
INSERT INTO `book` VALUES ('A0000002', '卖火柴的小女孩', '0', '童话故事', '火柴和小女孩');
INSERT INTO `book` VALUES ('A0000003', '福尔摩斯探案集', '0', '悬疑', null);
INSERT INTO `book` VALUES ('A0000004', '坏小孩', '0', '悬疑', null);
INSERT INTO `book` VALUES ('A0000005', '大约在冬季', '0', '爱情', null);
INSERT INTO `book` VALUES ('A0000006', '测试', '0', '悬疑', null);

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `roleid` int NOT NULL AUTO_INCREMENT COMMENT '角色id',
  `rolename` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT '角色名',
  PRIMARY KEY (`roleid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES ('1', '系统管理员');
INSERT INTO `role` VALUES ('2', '图书管理员');
INSERT INTO `role` VALUES ('3', '教师');
INSERT INTO `role` VALUES ('4', '学生');

-- ----------------------------
-- Table structure for tb_borrow
-- ----------------------------
DROP TABLE IF EXISTS `tb_borrow`;
CREATE TABLE `tb_borrow` (
  `bookid` char(8) NOT NULL,
  `userid` char(8) NOT NULL,
  `borrowtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- ----------------------------
-- Records of tb_borrow
-- ----------------------------
INSERT INTO `tb_borrow` VALUES ('A0000001', 'U0000123', '2023-05-10 15:29:04');
INSERT INTO `tb_borrow` VALUES ('A0000001', 'U0000999', '2023-05-02 19:48:18');
INSERT INTO `tb_borrow` VALUES ('A0000003', 'U0000123', '2023-04-06 20:58:25');
INSERT INTO `tb_borrow` VALUES ('A0000002', 'U0000999', '2023-06-25 10:09:31');
INSERT INTO `tb_borrow` VALUES ('A0000004', 'U0000999', '2023-06-25 13:02:47');
INSERT INTO `tb_borrow` VALUES ('A0000005', 'U0000999', '2023-06-25 13:16:15');
INSERT INTO `tb_borrow` VALUES ('A0000005', 'U0000123', '2023-06-25 19:21:34');
INSERT INTO `tb_borrow` VALUES ('A0000003', 'U0000999', '2023-06-27 21:02:36');
INSERT INTO `tb_borrow` VALUES ('A0000006', 'U0000123', '2023-06-27 21:18:37');
INSERT INTO `tb_borrow` VALUES ('A0000006', 'U7657843', '2023-06-27 21:21:51');

-- ----------------------------
-- Table structure for tb_return
-- ----------------------------
DROP TABLE IF EXISTS `tb_return`;
CREATE TABLE `tb_return` (
  `bookid` char(8) NOT NULL,
  `userid` char(8) NOT NULL,
  `returntime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- ----------------------------
-- Records of tb_return
-- ----------------------------
INSERT INTO `tb_return` VALUES ('A0000001', 'U0000123', '2023-06-23 15:32:27');
INSERT INTO `tb_return` VALUES ('A0000005', 'U0000999', '2023-06-25 14:10:56');
INSERT INTO `tb_return` VALUES ('A0000003', 'U0000123', '2023-06-26 13:17:39');
INSERT INTO `tb_return` VALUES ('A0000006', 'U0000123', '2023-06-27 21:21:11');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `userid` char(8) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT '用户id',
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT '用户名',
  `userrole` int NOT NULL DEFAULT '4' COMMENT '用户角色号',
  `age` int DEFAULT '0' COMMENT '年龄',
  `sex` int DEFAULT '1' COMMENT '性别',
  `phone` char(11) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT '手机号',
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '123456' COMMENT '密码',
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('U0000001', '系统管理员1', '1', '30', '1', '15111111111', 'EFG@AB');
INSERT INTO `user` VALUES ('U0000011', '图书管理员-小名', '2', '20', '0', '15112222222', 'EFG@AB');
INSERT INTO `user` VALUES ('U0000012', 'bookmanager2', '2', '22', '0', '13222222222', 'EFG@AB');
INSERT INTO `user` VALUES ('U0000123', '张东升', '3', '25', '0', '15123456789', 'EFG@AB');
INSERT INTO `user` VALUES ('U0000999', '朱朝阳', '4', '21', '0', '13294657823', 'EFG@AB');
INSERT INTO `user` VALUES ('U7657843', '小亮', '4', '12', '0', '15234567876', 'EFG@AB');
