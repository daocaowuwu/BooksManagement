const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  transpileDependencies: true
})
module.exports ={
  devServer:{
    port:8787,
    proxy:{
      '/system':{
        target:'http://localhost:80',
        changeOrigin:true,
        pathRewrite:{
          '^/system':'/system'
        }
      },
      '/book':{
        target:'http://localhost:80',
        changeOrigin:true,
        pathRewrite:{
          '^/book':'/book'
        }
      }
    }
  }
}