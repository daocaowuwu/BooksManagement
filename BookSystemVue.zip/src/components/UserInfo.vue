<template>
  <div id="info">
    <el-form ref="form" :model="user" :rules="rules" label-width="90px">
      <el-form-item label="用户id" prop="userid">
      <el-input readonly v-model="user.userid" maxlength="8" />
    </el-form-item>
    <el-form-item label="用户角色id" prop="userrole">
      <el-input readonly v-model="user.userrole" maxlength="1" />
    </el-form-item>
    <el-form-item label="用户昵称" prop="username">
      <el-input v-model="user.username" maxlength="30" />
    </el-form-item> 
    <el-form-item label="手机号码" prop="phone">
      <el-input v-model="user.phone" maxlength="11" />
    </el-form-item>
    <el-form-item label="年龄" prop="age">
      <el-input v-model="user.age" maxlength="3"  type="number"/>
    </el-form-item>
    <el-form-item label="性别">
      <el-radio-group   v-model="user.sex">
        <el-radio :label="0">男</el-radio>
        <el-radio :label="1">女</el-radio>
      </el-radio-group>
    </el-form-item>
    <el-form-item>
      <el-button type="primary" size="mini" @click="submit">保存</el-button>
    </el-form-item>
  </el-form>
  </div>
</template>

<script>
import { updateUserProfile } from "../system/userInfo.js"
export default {
  name: 'UserInfo',
  data() {
    return {
      user:this.$store.getters.userInfo,
      // 表单校验
      rules: {
        username: [
          { required: true, message: "用户昵称不能为空", trigger: "blur" }
        ],
        phone: [
          { required: true, message: "手机号码不能为空", trigger: "blur" },
          {
            pattern: /^1[3|4|5|6|7|8|9][0-9]\d{8}$/,
            message: "请输入正确的手机号码",
            trigger: "blur"
          }
        ]
      }
    };
  },
  methods: {
    submit() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          updateUserProfile(this.user);
        }
      });
    },
    close() {
      this.$tab.closePage();
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
div{
  width: 400px;
  margin-left: 25%;
}
#info{
  position: relative;
  top:50px;
}
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
.el-button{
  background-color: #00D9D0 ;
  color: white;
  width:80px;
  height:20px;
  border:0;
  font-size: 16px;
  box-sizing: content-box;
  border-radius: 5px;
}
.el-button:hover{
  background-color: #4699E1;
}
</style>
