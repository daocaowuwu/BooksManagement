<template>
<div id="searchbook">
  <el-card class="box-card">
<!--  搜索框-->
  <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="68px">
    <el-form-item >
      <div class="lableedit">
      <span slot="label" prop="bookid">
      图书号
      </span>
    </div>
      <el-input
          v-model="queryParams.bookid"
          placeholder="请输入图书号"
          clearable
          @keyup.enter.native="handleQuery"
      />
    </el-form-item>
    <el-form-item>
      <div class="lableedit2">
      <span slot="label" prop="bookname">
        图书名称
      </span>
    </div>
      <el-input
          v-model="queryParams.bookname"
          placeholder="请输入图书名称"
          clearable
          @keyup.enter.native="handleQuery"
      />
    </el-form-item>
    <el-form-item>
      <div class="lableedit3">
      <span slot="label" prop="booksort">
        图书种类
      </span>
    </div>
      <el-input
          v-model="queryParams.booksort"
          placeholder="请输入图书种类"
          clearable
          @keyup.enter.native="handleQuery"
      />
    </el-form-item>
    <el-form-item>
      <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
    </el-form-item>
  </el-form>

<!--    图书显示区域-->
    <el-table v-loading="loading" :data="bookList" >
      <el-table-column label="图书id" align="center" prop="bookid" />
      <el-table-column label="图书名称" align="center" prop="bookname" />
      <el-table-column label="图书种类" align="center" prop="booksort" />
      <el-table-column label="图书描述" align="center" prop="description" />
      <el-table-column label="图书状态" align="center" prop="bookstate" />
    </el-table>

    <!--分页-->
    <el-pagination
      v-show="total>0"
      :total="total"
      :page-size="5"
      :current-page="queryParams.pageNum"
      :page-sizes="[5, 10, 15, 20]"
      @current-change="handleCurrentChange"
      :page.sync="queryParams.pageNum"
    />
  </el-card>

</div>
</template>

<script>
export default {
  name:'SearchBook',
  data(){
    return{
      // 遮罩层
      loading: true,
      showSearch: true,
      // 总条数
      total: 0,
      // 图书表格数据
      bookList: [],
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 5,
        bookid: null,
        bookname: null,
        booksort: null
      },
    }
  },
  created() {
    this.getList();
  },
  methods:{
    handleCurrentChange(val){
      this.queryParams.pageNum = val
      this.getList();
    },
    listBook(query) {
    return this.$http.get( 'http://localhost:8787/book/list',{params:{
      pageNum:(query.pageNum-1)*query.pageSize,
      pageSize:query.pageSize,
      bookid:query.bookid,
      bookname:query.bookname,
      booksort:query.booksort
    }
  }).then(response => {
      if(response.data.code==200){
    this.bookList=[...response.data.data];
    this.total = parseInt(response.data.msg);
    this.loading=false
      }
      else
      this.$message.error("查询失败！");
      this.loading=false
  })
},
    /** 查询图书列表 */
    getList() {
      this.loading = true;
      this.listBook(this.queryParams);
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    }
  }
}
</script>

<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
.el-table{
  padding-top: -150px;
}
.el-pagination{
  padding-top: 70px;
}
.el-form{
  margin-top: 20px;
  height: 60px;
}
.el-form-item{
    margin-left: 90px;
    width: 200px;
}
.el-button{
  margin-top: 0px;
  margin-left: 3px;
}
.lableedit{
  position: absolute;
  top:2px;
  left:-55px;
}
.lableedit2{
  position: absolute;
  top:2px;
  left:-63px;
}
.lableedit3{
  position: absolute;
  top:2px;
  left:-63px;
}


</style>