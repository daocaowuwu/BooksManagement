<template>
  <div id="readermanage">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="68px" 
    style="height: 80px; margin-top: 20px;">
        <el-form-item >
        <div class="lableedit">
      <span slot="label" prop="userid">
        用户id
      </span>
    </div>
        <el-input
          v-model="queryParams.userid"
          placeholder="请输入用户id"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
      </el-form-item>
    </el-form>


    <el-table v-loading="loading" :data="userList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="用户id" align="center" prop="userid" />
      <el-table-column label="用户名" align="center" prop="username" />
      <el-table-column label="用户角色号" align="center" prop="userrole" />
      <el-table-column label="年龄" align="center" prop="age" />
      <el-table-column label="性别" align="center" prop="sex" />
      <el-table-column label="手机号" align="center" prop="phone" />
      <el-table-column label="书籍id" align="center" prop="bookid" />
      <el-table-column label="已借天数" align="center" prop="days" />
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
          >修改</el-button>
          <!-- <el-button
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
          >删除</el-button> -->
        </template>
      </el-table-column>
    </el-table>
    
    <el-pagination
      v-show="total>0"
      :total="total"
      :page-size="5"
      :current-page="queryParams.pageNum"
      :page-sizes="[5, 10, 15, 20]"
      @current-change="handleCurrentChange"
      :page.sync="queryParams.pageNum"
    />

    <!-- 修改借阅日期对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="800px"  append-to-body >
      <el-form ref="form" :model="form" :rules="rules" label-width="80px">
        <el-form-item  label="用户id" prop="userid">
          <el-input readonly v-model="form.userid" placeholder="请输入用户id" style="width: 200px;"/>
        </el-form-item>
        <el-form-item label="书籍号" prop="bookid">
          <el-input readonly v-model="form.bookid" placeholder="请输入书籍号" style="width: 200px;"/>
        </el-form-item>
        <el-form-item label="借书时间" prop="borrowtime">
          <el-input v-model="form.borrowtime" placeholder="请输入借阅时间" style="width: 200px;"/>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <!-- <el-button type="primary" @click="submitForm1">添 加</el-button> -->
        <el-button type="success" @click="submitForm2">修 改</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: 'ReaderManage',
 
  data() {
    return {
     // 遮罩层
     loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 用户管理表格数据
      userList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 5,
        userid: null
      },
      getParams:{
        userid: null,
        bookid: null
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        userid: [
          { required: true, message: "用户id不能为空", trigger: "blur" }
        ],
        bookid: [
          { required: true, message: "不能为空", trigger: "blur" }
        ],
        borrowtime: [
          { required: true, message: "不能为空", trigger: "blur" }
        ]
      }
      }
  },
  created() {
    this.getList();
  },
  methods: {
    handleCurrentChange(val){
      this.queryParams.pageNum = val
      this.getList();
    },
    updateBorrow(data) {
    return this.$http.put( 'http://localhost:8787/book/borrowupdate',data).then(response => {
      if(response.data.code==200)
    this.$message.success("修改成功");
    else
    this.$message.error("修改失败！");
    this.open = false;
    this.getList();
    return response;
  })
},

    getBorrowInfo() {
    return this.$http.get( 'http://localhost:8787/book/borrowinfo',{params:this.getParams}).then(response => {
    this.form = response.data.data;
    console.log(response.data.data);
    this.open = true;
    this.title = "图书详细信息";
  })
},
    listUser(query){
      this.$http.get( 'http://localhost:8787/system/reader',{params:{
      pageNum:(query.pageNum-1)*query.pageSize,
      pageSize:query.pageSize,
      userid:query.userid
    }
  }).then(response => {
            if(response.data.code==200)
            {
              this.userList=[];
              this.userList=[...response.data.data];
              this.total = parseInt(response.data.msg);
              this.loading = false;
            }
       })
    },
    /** 查询用户管理列表 */
    getList() {
      this.loading = true;
      this.listUser(this.queryParams)
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        userid: null,
        bookid: null,
        borrowtime: null
      };
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.userid)
      this.single = selection.length!==1
      this.multiple = !selection.length
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset();
      this.getParams.userid = row.userid
      this.getParams.bookid=row.bookid
      this.getBorrowInfo()
    },
    /** 修改按钮 */
    submitForm2() {
      this.$refs["form"].validate(valid => {
        if (valid) {
            this.updateBorrow(this.form);
        }
      });
    }
  }
}
</script>


<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}

.lableedit{
  position: absolute;
  top:2px;
  left:-55px;
}
.el-form-item{
    margin-left: 90px;
    width: 200px;
}
.el-pagination{
  position:relative;
  top:20px;
}
.el-table{
  position: relative;
  top:-10px
}
</style>
