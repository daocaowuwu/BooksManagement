<template>
<div id="systemmanager">
  <!--  卡片视图-->
  <el-card class="box-card">
    <!--  搜索与添加区域-->
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="68px">
      <el-form-item label="用户id" prop="userid">
        <el-input
            v-model="queryParams.userid"
            placeholder="请输入用户id"
            clearable
            @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="用户名" prop="username">
        <el-input
            v-model="queryParams.username"
            placeholder="请输入用户名"
            clearable
            @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
            type="primary"
            plain
            icon="el-icon-plus"
            size="mini"
            @click="handleAdd"
        >新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
            type="danger"
            plain
            icon="el-icon-delete"
            size="mini"
            @click="handleDelete"
        >删除</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <!-- 用户列表区域-->
    <el-table v-loading="loading" :data="userList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="用户id" align="center" prop="userid" />
      <el-table-column label="用户名" align="center" prop="username" />
      <el-table-column label="用户角色号" align="center" prop="userrole" />
      <el-table-column label="年龄" align="center" prop="age" />
      <el-table-column label="性别" align="center" prop="sex" />
      <el-table-column label="手机号" align="center" prop="phone" />
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
              size="mini"
              type="text"
              icon="el-icon-edit"
              @click="handleUpdate(scope.row)"
          >修改</el-button>
          <el-button
              size="mini"
              type="text"
              icon="el-icon-delete"
              @click="handleDelete(scope.row)"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!--分页-->
    <el-pagination
      v-show="total>0"
      :total="total"
      :page-size="5"
      :current-page="queryParams.pageNum"
      :page-sizes="[5, 10, 15, 20]"
      @current-change="handleCurrentChange"
      :page.sync="queryParams.pageNum"
    />

  </el-card>

  <!-- 修改用户管理对话框 -->
  <el-dialog :title="title" :visible.sync="open" width="500px" append-to-body>
    <el-form ref="form" :model="form" :rules="rules" label-width="80px">
      <el-form-item label="用户id" prop="userid">
        <el-input v-model="form.userid" placeholder="请输入用户id" style="width: 200px;"/>
      </el-form-item>
      <el-form-item label="用户名" prop="username">
        <el-input v-model="form.username" placeholder="请输入用户名" style="width: 200px;"/>
      </el-form-item>
      <el-form-item label="用户角色号" prop="userrole">
        <el-input v-model="form.userrole" readonly style="width: 200px;"/>
      </el-form-item>
      <el-form-item label="年龄" prop="age">
        <el-input v-model="form.age" placeholder="请输入年龄" style="width: 200px;"/>
      </el-form-item>
      <el-form-item label="性别">
        <el-radio-group v-model="form.sex">
          <el-radio :label="0">男</el-radio>
          <el-radio :label="1">女</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="手机号" prop="phone">
        <el-input v-model="form.phone" placeholder="请输入手机号" style="width: 200px;"/>
      </el-form-item>
      <el-form-item label="密码" prop="password">
        <el-input v-model="form.password" placeholder="请输入密码" style="width: 200px;"/>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="success" @click="submitForm2">修 改</el-button>
      <el-button @click="cancel">取 消</el-button>
    </div>
  </el-dialog>

  <!-- 添加用户管理对话框 -->
  <el-dialog :title="title" :visible.sync="openT" width="500px" append-to-body>
    <el-form ref="formT" :model="formT" :rules="rulesT" label-width="80px">
      <el-form-item label="用户id" prop="userid">
        <el-input v-model="formT.userid" placeholder="请输入用户id" />
      </el-form-item>
      <el-form-item label="用户名" prop="username">
        <el-input v-model="formT.username" placeholder="请输入用户名" />
      </el-form-item>
      <el-form-item label="用户角色号" prop="userrole">
        <el-input v-model="formT.userrole" readonly/>
      </el-form-item>
      <el-form-item label="年龄" prop="age">
        <el-input v-model="formT.age" placeholder="请输入年龄" />
      </el-form-item>
      <el-form-item label="性别">
        <el-radio-group v-model="formT.sex">
          <el-radio :label="0">男</el-radio>
          <el-radio :label="1">女</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="手机号" prop="phone">
        <el-input v-model="formT.phone" placeholder="请输入手机号" />
      </el-form-item>
      <el-form-item label="密码" prop="password">
        <el-input v-model="formT.password" placeholder="请输入密码" />
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="primary" @click="submitForm1">添 加</el-button>
      <el-button @click="cancel">取 消</el-button>
    </div>
  </el-dialog>
</div>
</template>

<script>
export default {
  name:'SystemManager',
  data(){
    return{
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      openT: false,
      // 获取用户列表的参数对象
      queryParams: {
        pageNum: 1,
        pageSize: 5,
        userid: null,
        username: null,
      },
      userList: [],
      total: 0,
      form:{
        userrole: "2",
      },
      formT:{
        userrole: "2",
      },
      rules: {
        userid: [
          { required: true, message: "用户id不能为空", trigger: "blur" }
        ],
        username: [
          { required: true, message: "用户名不能为空", trigger: "blur" }
        ],
        phone: [
          { required: true, message: "手机号不能为空", trigger: "blur" },
          {
            pattern: /^1[3|4|5|6|7|8|9][0-9]\d{8}$/,
            message: "请输入正确的手机号码",
            trigger: "blur"
          }
        ],
        password: [
          { required: true, message: "密码不能为空", trigger: "blur" }
        ]
      },
      rulesT: {
        userid: [
          { required: true, message: "用户id不能为空", trigger: "blur" }
        ],
        username: [
          { required: true, message: "用户名不能为空", trigger: "blur" }
        ],
        phone: [
          { required: true, message: "手机号不能为空", trigger: "blur" },
          {
            pattern: /^1[3|4|5|6|7|8|9][0-9]\d{8}$/,
            message: "请输入正确的手机号码",
            trigger: "blur"
          }
        ],
        password: [
          { required: true, message: "密码不能为空", trigger: "blur" }
        ]
      }
    }
  },
  created() {
    this.getList();
  },
  methods:{
    handleCurrentChange(val){
      this.queryParams.pageNum = val
      this.getList();
    },
    delManager(userid) {
      return this.$http.delete('http://localhost:8787/system/readerdelete/'+userid).then(response => {
        this.getList();
        if(response.data.code==200)
        this.$message.success("删除成功");
        else
        this.$message.error(response.data.msg);
      }).catch(() => {})
    },

    addManager(data) {
    return this.$http.post( 'http://localhost:8787/system/readeradd',data).then(response => {
    if(response.data.code==200)
    this.$message.success("新增成功");
    else
    this.$message.error("新增失败！");
    this.openT = false;
    this.getList();
    return response;
  })
},

updateManager(data) {
    return this.$http.put( 'http://localhost:8787/system/userprofile',data).then(response => {
      if(response.data.code==200)
    this.$message.success("修改成功");
    else
    this.$message.error("修改失败！");
    this.open = false;
    this.getList();
    return response;
  })
},

    getManager(userid) {
    return this.$http.get( 'http://localhost:8787/system/readerdetail/'+userid).then(response => {
    this.form = response.data.data;
    console.log(response.data.data);
    this.open = true;
    this.title = "读者详细信息";
  })
},

    listManager(query) {
    return this.$http.get( 'http://localhost:8787/system/managerslist',{params:{
      pageNum:(query.pageNum-1)*query.pageSize,
      pageSize:query.pageSize,
      userid:query.userid,
      username:query.username
    }
  }).then(response => {
      if(response.data.code==200){
      this.userList=[...response.data.data];
    this.total = parseInt(response.data.msg);
    console.log(this.userList,this.total)
    }
    else
      this.$message.error("查询失败！");
  })
},
    /** 查询用户管理列表 */
    getList() {
      this.loading = true;
      this.listManager(this.queryParams).then(()=>{
        this.loading = false;
      })
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.openT = false;
      this.reset();
    },
    //多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.userid)
      this.single = selection.length!==1
      this.multiple = !selection.length
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      this.openT = true;
      this.title = "添加用户";
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset();
      const userid = row.userid
      this.getManager(userid)
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const userids = row.userid || this.ids;
      this.$confirm('此操作将永久删除该"' + userids + '"用户, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          console.log(userids)
          if(userids==row.userid) {
            this.delManager(userids);
          }
          else{
          userids.forEach(element => {
          this.delManager(element);
            });
            }
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '取消删除'
          });          
        });
    },
    // 表单重置
    reset() {
      this.form = {
        userid: null,
        username: null,
        userrole: null,
        age: null,
        sex: null,
        phone: null,
        password: null
      };
    },
    /** 添加按钮 */
    submitForm1() {
      this.$refs["formT"].validate(valid => {
        if (valid) {
          this.addManager(this.formT);
        }
      });
    },
    /** 修改按钮 */
    submitForm2() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          this.updateManager(this.form);
        }
      });
    },
  }
}
</script>

<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
.el-form-item__label {
  float: left;
}
.el-pagination{
  margin-top: 40px;
}
</style>