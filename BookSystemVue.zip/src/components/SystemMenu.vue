<template>
  <div id="readermenu">
    <el-container  style="height: 100vh;">
      <el-aside width="200px">
        <el-menu id="navMenu"  :router="true" :default-active="$route.path">
          <!-------------------------------------------------------------------------------------------------------->

          <template slot="title">分组一</template>
          <el-menu-item-group>
            <el-menu-item index="/systemmanager"  ref="systemmanager">图书管理员管理</el-menu-item>
          </el-menu-item-group>
        </el-menu>
      </el-aside>
      <el-container>
        <el-header>
          <span class="fontheader">图书管理系统</span>
      <el-button @click="$store.commit('SYNUSERINFO',{})">退出登录</el-button>
        </el-header>
        <el-main id="menuMain">
          <router-view></router-view>
        </el-main>

      </el-container>
    </el-container>

  </div>
</template>

<script>
export default {
  name:'SystemMenu',
  data() {
    return {

    }
  },
  mounted() {
    (this.$refs.systemmanager).$el.click();
  }
}

</script>

<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
.el-header{
  background-color:#1EADE5;
  display: flex;
  justify-content: space-between;
  padding-left: 0;
  align-items: center;
  height: 18px;
}
.el-button{
  background-color: #00D9D0 ;
  color: white;
  width:80px;
  height:15px;
  border:0;
  font-size: 14px;
  box-sizing: content-box;
  border-radius: 5px;
}
.el-button:hover{
  background-color: #4699E1;
}
.fontheader{
  margin-left: 15px;
  color: black;
  font-size: 25px;
  text-shadow: 0 2px 3px #0081B1;
}
.el-footer {
  background-color:#FFB067;
  color: #333;
  text-align: center;
  line-height: 60px;
}

.el-aside {
  background-color: #D3DCE6;
  color: #333;
  text-align: center;
  line-height: 160px;
}

.el-main {
  /* background-color: #E9EEF3;
  color: #333; */
  text-align: center;
}

body > .el-container {
  margin-bottom: 40px;
}
.el-container:nth-child(5) .el-aside,
.el-container:nth-child(6) .el-aside {
  line-height: 260px;
}

.el-container:nth-child(7) .el-aside {
  line-height: 320px;
}

</style>