<template>
  <div id="borrowreturn">
    <div>
    <el-table v-loading="loading" :data="userList">
      <el-table-column label="用户id" align="center" prop="userid" />
      <el-table-column label="用户名" align="center" prop="username" />
      <el-table-column label="用户角色号" align="center" prop="userrole" />
      <el-table-column label="年龄" align="center" prop="age" />
      <el-table-column label="性别" align="center" prop="sex" />
      <el-table-column label="手机号" align="center" prop="phone" />
      <el-table-column label="书籍号" align="center" prop="bookid" />
      <el-table-column label="已借天数" align="center" prop="days" />
      <el-table-column label="已借数量" align="center" prop="borrowed" />
      
    </el-table>
      <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            :disabled="borrowable"
            @click="handleBorrow()"
          >借书</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-delete"
            :disabled="returnable"
            @click="handleReturn()"
          >还书</el-button>

      <el-pagination
      v-show="total>0"
      :total="total"
      :page-size="5"
      :current-page="queryParams.pageNum"
      :page-sizes="[5, 10, 15, 20]"
      @current-change="handleCurrentChange"
      :page.sync="queryParams.pageNum"
    />
     </div>


   <!-- 输入借阅人用户id 确有此人则可还书；没有超过期限的书且已借数<11的学生/<16的老师可借 -->
   <el-dialog  :visible.sync="open" width="500px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="借阅人id" prop="userid">
          <el-input v-model="form.userid" placeholder="请输入借阅人id号" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
      </div>
    </el-dialog>

    <!-- 借书/还书 -->
    <el-dialog :title="title" :visible.sync="openBR" width="500px" append-to-body>
      <el-form ref="formBR" :model="formBR" :rules="rulesBR" label-width="80px">
        <el-form-item label="书籍id" prop="bookid">
          <el-input v-model="formBR.bookid" placeholder="请输入书籍id号" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitFormB(formBR.bookid)" v-if="this.title=='借书'">借这本书</el-button>
        <el-button type="success" @click="submitFormR(formBR.bookid)" v-if="this.title=='还书'">还这本书</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: 'BorrowReturn',
 
  data() {
    return {
      // 遮罩层
     loading: true,
      //
      title:'',
      //是否已上传正确读者id
      loaded: false,
      // 是否显示弹出层
      open: true,
      //是否弹出借还书弹出层
      openBR:false,
      //借阅人id
      readerid:"",
      //借阅人juese
      readerrole:null,
      //书籍id
      bookid:"",
      // 总条数
      total: 0,
      //不可借
      borrowable:false,
      //不可还
      returnable:false,
      //借还参数
      queryParamsBR:{
        userid:"",
        bookid:""
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        userid: [
          { required: true, message: "借阅者id不能为空", trigger: "blur" }
        ]
      },
      // 用户管理表格数据
      userList: [
        {
          borrowed:0
        }
      ],
      // 查询参数
      queryParams: {
        userid: this.readerid,
        pageNum: 1,
        pageSize: 5,
      },
      // 借阅表单参数
      formBR: {},
      // 借阅表单校验
      rulesBR: {
        bookid: [
          { required: true, message: "书籍id不能为空", trigger: "blur" }
        ]
      },
      }
  },
  created() {
    
  },
  methods: {
    handleCurrentChange(val){
      this.queryParams.pageNum = val
      this.getReader(this.readerid);
    },
    getReader(userid){
      this.borrowable=false;
      this.returnable=false;
      this.queryParams.userid=this.form.userid;
      
      this.$http.get( 'http://localhost:8787/system/reader',{params:{
      pageNum:(this.queryParams.pageNum-1)*this.queryParams.pageSize,
      pageSize:this.queryParams.pageSize,
      userid:this.queryParams.userid
    }
  }).then(response => {
            if(response.data.code==200)
            {
              
              this.$message.success("操作成功！")
              this.readerid = userid;
              this.userList=[];
              this.userList=[...response.data.data];
              //遍历 确定是否可借还
              this.userList.filter(user => {
                if(((user.days>30||user.borrowed>10)&&user.userrole=='4')||((user.days>60||user.borrowed>15)&&user.userrole=='3'))
                {
                  this.borrowable = true;
                }
                if(user.borrowed>0)
                  this.returnable=false;
              })
              this.readerrole=response.data.data.userrole;
              this.loaded=true;
              this.open=false;
              this.loading = false;
              console.log(this.userList,this.borrowable,this.returnable);
            }
            else{
              this.$message.error("操作失败！")
            }
       })
    },
    submitForm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          this.getReader(this.form.userid);
        }
      });
    },
    submitFormB(bookid) {
      this.$refs["formBR"].validate(valid => {
        if (valid) {
          this.queryParams.pageNum=1
          this.queryParamsBR.userid=this.readerid;
          this.queryParamsBR.bookid=bookid;
          this.$http.get( 'http://localhost:8787/book/borrow',{params:this.queryParamsBR}).then(response => {
            if(response.data.code==200)
            {
              this.openBR=false;
              this.$message.success("借书成功");
              this.loading = true;
              this.getReader(this.readerid);
            }
            else{
              this.$message.error("借书失败")
            }
       })
        }
      });
    },
    submitFormR(bookid) {
      this.$refs["formBR"].validate(valid => {
        if (valid) {
          this.queryParams.pageNum=1
          this.queryParamsBR.userid=this.readerid;
          this.queryParamsBR.bookid=bookid;
          this.$http.get( 'http://localhost:8787/book/return',{params:this.queryParamsBR}).then(response => {
            if(response.data.code==200)
            {
              this.openBR=false;
              this.$message.success("还书成功");
              this.getReader(this.readerid);
            }
            else{
              this.$message.error("还书失败")
            }
       })
        }
      });
    },
    handleBorrow(){
      this.title="借书";
      this.openBR=true;
    },
    handleReturn(){
      this.title="还书";
      this.openBR=true;
    },
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
