<template>
<div id="brinfo">
  <el-card class="box-card">
<!--   借阅信息显示区域-->
    <el-table v-loading="loading" :data="BRList" >
      <el-table-column label="图书id" align="center" prop="bookid" />
      <el-table-column label="图书名称" align="center" prop="bookname" />
      <el-table-column label="借书时间" align="center" prop="borrowtime" />
    </el-table>

    <!--分页-->
    <el-pagination
      v-show="total>0"
      :total="total"
      :page-size="5"
      :current-page="queryParams.pageNum"
      :page-sizes="[5, 10, 15, 20]"
      @current-change="handleCurrentChange"
      :page.sync="queryParams.pageNum"
    />

  </el-card>
</div>
</template>

<script>

export default {
  name:'BRInfo',
  data(){
    return{
      loading:true,
      BRList:[],
      total:0,
      user:this.$store.getters.userInfo,
      queryParams:{
        pageNum: 1,
        pageSize: 5,
        userid:null
      }
    }
  },
  created() {
    this.getList()
  },
  methods:{
    handleCurrentChange(val){
      this.queryParams.pageNum = val
      this.getList();
    },
    // 借阅图书列表
listBRInfo(userid) {
  this.queryParams.userid = userid;
  let query=this.queryParams
  query.pageNum=(query.pageNum-1)*query.pageSize;
    return this.$http.get( 'http://localhost:8787/system/readerborrow',{params:{
      pageNum:(query.pageNum-1)*query.pageSize,
      pageSize:query.pageSize,
      userid:query.userid
    }
  }).then(response => {
    if(response.data.code==200){
      this.$message.success("查询成功！")
        this.BRList =[... response.data.data];
        this.total = parseInt(response.data.msg);}
        this.loading = false;
    })
},
    getList(){
      this.loading = true;
      this.listBRInfo(this.user.userid)
    }
  }
}
</script>


<style scoped>
.el-pagination{
  padding-top: 70px;
}
.el-table_body-wrapper{
  padding-top: -100px;
}
</style>