<template>
  <div id="bookmenu">
    <el-container>
  <el-aside width="200px">
    <el-menu id="navMenu"  :router="true" :default-active="$route.path">
<!-------------------------------------------------------------------------------------------------------->
        
          <template slot="title">分组一</template>
          <el-menu-item-group>
            <el-menu-item ref="userinfo" index="/userinfo">个人信息</el-menu-item>
            <el-menu-item ref="bookmanage" index="/bookmanage">图书管理</el-menu-item>
            <el-menu-item index="/readermanage">读者管理</el-menu-item>
            <el-menu-item index="/borrowinfo">借阅信息</el-menu-item>
            <el-menu-item index="/borrowreturn">借还书</el-menu-item>
        </el-menu-item-group>
      </el-menu>
  </el-aside>
  <el-container>
    <el-header>
      <span class="fontheader">图书管理系统</span>
      <el-button @click="$store.commit('SYNUSERINFO',{})">退出登录</el-button>
    </el-header>
    <el-main id="menuMain">         
          <router-view></router-view>
    </el-main>
    
  </el-container>
</el-container>

  </div>
</template>

<script>
export default {
  name: 'BookMenu',
  data() {
    return {
      
  }
},
mounted() {
  (this.$refs.userinfo).$el.click();
}
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
.el-header{
  background-color:#1EADE5;
  display: flex;
  justify-content: space-between;
  padding-left: 0;
  align-items: center;
  height: 18px;
}
.el-button{
  background-color: #00D9D0 ;
  color: white;
  width:80px;
  height:15px;
  border:0;
  font-size: 14px;
  box-sizing: content-box;
  border-radius: 5px;
}
.el-button:hover{
  background-color: #4699E1;
}
.fontheader{
  margin-left: 15px;
  color: black;
  font-size: 16px;
  text-shadow: 0 1px 2px black;
}
.el-footer {
    background-color: #1EADE5;
    color: #333;
    text-align: center;
    line-height: 60px;
    height: 18px;
  }
  
  .el-aside {
    background-color: #D3DCE6;
    color: #333;
    text-align: center;
    line-height: 160px;
  }
  
  .el-main {
    /* background-color: #E9EEF3;
    color: #333; */
    text-align: center;
    line-height: 150px;
  }
  
  body > .el-container {
    margin-bottom: 40px;
  }
  .el-container:nth-child(5) .el-aside,
  .el-container:nth-child(6) .el-aside {
    line-height: 260px;
  }
  
  .el-container:nth-child(7) .el-aside {
    line-height: 320px;
  }
  .el-menu-item{
    height: 50px;
  }
  .el-menu-item-group{
    height: 300px;
  }
</style>
