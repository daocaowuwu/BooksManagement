<template>
  <div id="bookmanage">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="68px" 
    style="height: 80px; margin-top: 20px;">
      <el-form-item >
        <div class="lableedit">
      <span slot="label" prop="bookid">
      图书号
      </span>
    </div>
        <el-input
          v-model="queryParams.bookid"
          placeholder="请输入图书号"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item>
      <div class="lableedit2">
      <span slot="label" prop="bookname">
        图书名称
      </span>
    </div>
        <el-input
          v-model="queryParams.bookname"
          placeholder="请输入图书名称"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item>
      <div class="lableedit3">
      <span slot="label" prop="booksort">
        图书种类
      </span>
    </div>
        <el-input
          v-model="queryParams.booksort"
          placeholder="请输入图书种类"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="Information"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
        >添加</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="el-icon-delete"
          size="mini"
          
          @click="handleDelete"
        >删除</el-button>
      </el-col>
    </el-row>

    <el-table v-loading="loading" :data="bookList" @selection-change="handleSelectionChange" class="tablecolumn">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="图书id" align="center" prop="bookid" />
      <el-table-column label="图书名称" align="center" prop="bookname" />
      <el-table-column label="图书种类" align="center" prop="booksort" />
      <el-table-column label="图书描述" align="center" prop="description"/>
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button class="buttoncon"
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
          >修改</el-button>
          <el-button class="buttoncon"
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    
    <el-pagination
      v-show="total>0"
      :total="total"
      :page-size="5"
      :current-page="queryParams.pageNum"
      :page-sizes="[5, 10, 15, 20]"
      @current-change="handleCurrentChange"
      :page.sync="queryParams.pageNum"
    />

    <!-- 修改图书对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="800px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="80px" >
        <el-form-item label="图书号" prop="bookid">
          <el-input v-model="form.bookid" placeholder="请输入图书号"  style="width: 200px;"/>
        </el-form-item>
        <el-form-item label="图书名称" prop="bookname">
          <el-input v-model="form.bookname" placeholder="请输入图书名称" style="width: 200px;"/>
        </el-form-item>
        <el-form-item label="图书种类" prop="booksort">
          <el-input v-model="form.booksort" placeholder="请输入图书种类" style="width: 200px;"/>
        </el-form-item>
        <el-form-item label="图书描述" prop="description">
          <el-input v-model="form.description" placeholder="请输入图书描述" style="width: 200px;"/>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="success" @click="submitForm2">修 改</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>

    <!-- 添加表单 -->
    <el-dialog :title="title" :visible.sync="openT" width="800px" append-to-body>
      <el-form ref="formT" :model="formT" :rules="rules" label-width="80px">
        <el-form-item label="图书号" prop="bookid">
          <el-input v-model="formT.bookid"  placeholder="请输入图书号" style="width: 200px;"/>
        </el-form-item>
        <el-form-item label="图书名称" prop="bookname">
          <el-input v-model="formT.bookname" placeholder="请输入图书名称" style="width: 200px;"/>
        </el-form-item>
        <el-form-item label="图书种类" prop="booksort">
          <el-input v-model="formT.booksort" placeholder="请输入图书种类" style="width: 200px;"/>
        </el-form-item>
        <el-form-item label="图书描述" prop="description">
          <el-input v-model="formT.description" placeholder="请输入图书描述" style="width: 200px;"/>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm1">添 加</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>

export default {
  name: 'BookManage',
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 图书表格数据
      bookList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      openT: false,
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 5,
        bookid: null,
        bookname: null,
        booksort: null
      },
      // 表单参数
      form: {
      },
      formT:{},
      // 表单校验
      rules: {
        bookid: [
          { required: true, message: "图书号不能为空", trigger: "blur" }
        ],
        bookname: [
          { required: true, message: "图书名称不能为空", trigger: "blur" }
        ],
        booksort: [
          { required: true, message: "图书种类不能为空", trigger: "blur" }
        ],
      }
    };
  },
  created() {
    this.getList();
  },
  methods: {
    handleCurrentChange(val){
      this.queryParams.pageNum = val
      this.getList();
    },

    delBook(BookId) {
      return this.$http.delete('http://localhost:8787/book/delete/'+BookId).then(response => {
        this.queryParams.pageNum=1;
        this.getList();
        if(response.data.code==200)
        this.$message.success("删除成功");
        else
        this.$message.error(response.data.msg);
      }).catch(() => {})
    },

    addBook(data) {
    return this.$http.post( 'http://localhost:8787/book/add',data).then(response => {
    if(response.data.code==200)
    this.$message.success("新增成功");
    else
    this.$message.error("新增失败！");
    this.openT = false;
    this.queryParams.pageNum=1;
    this.getList();
    return response;
  })
},

updateBook(data) {
    return this.$http.put( 'http://localhost:8787/book/update',data).then(response => {
      if(response.data.code==200)
    this.$message.success("修改成功");
    else
    this.$message.error("修改失败！");
    this.open = false;
    this.queryParams.pageNum=1;
    this.getList();
    return response;
  })
},

    getBook(BookId) {
    return this.$http.get( 'http://localhost:8787/book/detail/'+BookId).then(response => {
    this.form = response.data.data;
    console.log(response.data.data);
    this.open = true;
    this.title = "图书详细信息";
  })
},

    listBook(query) {
    return this.$http.get( 'http://localhost:8787/book/list',{params:{
      pageNum:(query.pageNum-1)*query.pageSize,
      pageSize:query.pageSize,
      bookid:query.bookid,
      bookname:query.bookname,
      booksort:query.booksort
    }
    }).then(response => {
      if(response.data.code==200){
    this.bookList=[...response.data.data];
    this.total = parseInt(response.data.msg);
    
    console.log(this.bookList,this.total)
      }
      else
      this.$message.error("查询失败！");
  })
},
    /** 查询图书列表 */
    getList() {
      this.loading = true;
      this.listBook(this.queryParams).then(()=>{
        this.loading = false;
      })
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.openT=false;
      this.reset();
    },
    //表单重置
    reset() {
      this.form = {
        bookid: null,
        bookname: null,
        booksort: null,
        description: null
      }
      //this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      //this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.bookid)
      this.single = selection.length!==1
      this.multiple = !selection.length
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      this.openT = true;
      this.title = "添加图书";
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset();
      this.open=true
      const bookid = row.bookid || this.ids
      this.getBook(bookid);
    },
    /** 表单添加按钮 */
    submitForm1() {
      this.$refs["formT"].validate(valid => {
        if (valid) {
            this.addBook(this.formT);
        }
      });
    },
    /** 表单修改按钮 */
    submitForm2() {
      this.$refs["form"].validate(valid => {
        if (valid) {
            this.updateBook(this.form);
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const bookids = row.bookid || this.ids;
      this.$confirm('此操作将永久删除该"' + bookids + '"书籍, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          console.log(bookids)
          if(bookids==row.bookid) {
            this.delBook(bookids);
          }
          else{
          bookids.forEach(element => {
          this.delBook(element);
            });
            }
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '取消删除'
          });          
        });
    }

    
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
.el-pagination{
  position: relative;
  top: -10px;
}
.lableedit{
  position: absolute;
  top:2px;
  left:-55px;
}
.lableedit2{
  position: absolute;
  top:2px;
  left:-63px;
}
.lableedit3{
  position: absolute;
  top:2px;
  left:-63px;
}
.el-form-item{
    margin-left: 90px;
    width: 200px;
}
.el-button{
  margin-top: 0px;
  margin-left: 3px;
}
.el-table{
  position: relative;
  top:-100px
}
.mb8{
  position: relative;
  left: 500px;
  top:-50px
}
.el-table_body-wrapper{
  position: relative;
  top:-140px;
}
.editbook > el-input{
  width: 100px;
}

</style>
