//引入vue
import Vue from "vue"
import store from '../store';
//必须实例化
var vue = new Vue()
  
  // 修改用户个人信息
  export function updateUserProfile(data) {
    
    console.log(JSON.stringify(data))
    return vue.$http.put( 'http://localhost:8787/system/userprofile',data,{
    contentType: "application/json;charset-utf-8"}
  ).then(response => {
        // 显示成功的操作
        vue.$message({
          message: '保存成功！',
          type: 'success'
          });
          store.commit('SYNUSERINFO',data)
        return response;
      });
  }