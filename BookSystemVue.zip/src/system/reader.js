
//引入vue
import Vue from "vue"
//必须实例化
var vue = new Vue()
// 查询用户列表
export function listUser(query) {
  return vue.$http.get( 'http://localhost:8787/system/reader/list',{params:query}).then(response => {
    vue.userList = response.data.rows;
    vue.total = response.data.total;
    vue.loading = false;
  })
}

// 查询用户详细信息
export function getUser(userid)  {
  return vue.$http.get( 'http://localhost:8787/system/reader/'+userid).then(response => {
    vue.form = response.data;
    vue.open = true;
    vue.title = "查询读者信息";
  })
}

// 新增用户
export function addUser(data) {
  return vue.$http.post( 'http://localhost:8787/system/reader',{data:data}).then(response => {
    vue.$modal.msgSuccess("新增成功");
    vue.open = false;
    vue.getList();
    return response;
  })
}

// 修改用户信息
export function updateUser(data) {
  return vue.$http.put( 'http://localhost:8787/system/reader',{data:data}).then(response => {
    vue.$modal.msgSuccess("修改成功");
    vue.open = false;
    vue.getList();
    return response;
  })
}

// 删除用户
export function delUser(userid) {
  return vue.$http.delete( 'http://localhost:8787/system/reader/'+userid).then(() => {
        vue.getList();
        vue.$modal.msgSuccess("删除成功");
      }).catch(() => {})
}
