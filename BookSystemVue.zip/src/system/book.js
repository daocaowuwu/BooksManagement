
//引入vue
import Vue from "vue"
//必须实例化
var vue = new Vue()
// 查询图书列表
export function listBook(query) {
  return vue.$http.get( 'http://localhost:8787/book/list',{params:query}).then(response => {
    vue.bookList=[...response.data.data];
    vue.total = parseInt(response.data.msg);
    //console.log(vue.bookList,vue.total)
    
  })
}

// 查询图书详细
export function getBook(BookId) {
  return vue.$http.get( 'http://localhost:8787/book/detail/'+BookId).then(response => {
    vue.form = response.data.data;
    vue.open = true;
    vue.title = "图书详细信息";
  })
}

// 新增图书
export function addBook(data) {
  return vue.$http.post( 'http://localhost:8787/system/book',{data:data}).then(response => {
    vue.$modal.msgSuccess("新增成功");
    vue.open = false;
    vue.getList();
    return response;
  })
}

// 修改图书
export function updateBook(data) {
  return vue.$http.put( 'http://localhost:8787/system/book',{data:data}).then(response => {
    vue.$modal.msgSuccess("修改成功");
    vue.open = false;
    vue.getList();
    return response;
  })
}

// 删除图书
export function delBook(BookId) {
  return vue.$http.delete( 'http://localhost:8787/system/book/'+BookId).then(() => {
        vue.getList();
        vue.$modal.msgSuccess("删除成功");
      }).catch(() => {})
}
