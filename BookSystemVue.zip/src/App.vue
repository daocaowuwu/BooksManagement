<template>
    <!-- <img alt="Vue logo" src="./assets/logo.png"> -->
    <!-- <HelloWorld msg="Welcome to Your Vue.js App"/> -->
    <div>
    <ReaderMenu v-if="this.$store.state.user.userrole>2"/>
    <BookMenu v-if="this.$store.state.user.userrole==2"/>
    <SystemMenu v-if="this.$store.state.user.userrole==1"/>
    <UserLogin v-if="this.$store.state.user.userrole==undefined"/>
  </div>
</template>

<script>
// import HelloWorld from './components/HelloWorld.vue'
import ReaderMenu from './components/ReaderMenu.vue'
import SystemMenu from './components/SystemMenu.vue'
import BookMenu from './components/BookMenu.vue'
import UserLogin from './components/UserLogin.vue'

export default {
  name: 'App',
  components: {
    BookMenu,
    UserLogin,
    SystemMenu,
    ReaderMenu
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
