//引入vue
import Vue from "vue"
import VueRouter from "vue-router";
import UserInfo from '../components/UserInfo.vue';
import BookManage from '../components/BookManage.vue';
import ReaderManage from '../components/ReaderManage.vue';
import BorrowReturn from '../components/BorrowReturn.vue';
import ReadersInfo from '../components/ReadersInfo.vue';

import BRInfo from "@/components/BRInfo.vue";
import ReaderInfo from "@/components/ReaderInfo.vue";
import SearchBook from "@/components/SearchBook.vue";
import SystemManager from "@/components/SystemManager.vue";

Vue.use(VueRouter);
export default new VueRouter({
    routes:[
        
                {
                    path:'/userinfo',
                    name:'userinfo',
                    component:UserInfo
                },
                {
                    path:'/bookmanage',
                    name:'bookmanage',
                    component:BookManage
                },
                {
                    path:'/borrowinfo',
                    name:'readermanage',
                    component:ReaderManage
                },
                {
                    path:'/borrowreturn',
                    name:'borrowreturn',
                    component:BorrowReturn
                },
                {
                    path:'/readermanage',
                    component:ReadersInfo
                },
                

                {
                    path:'/readerinfo',
                    name:'ReaderInfo',
                    component:ReaderInfo
                  },
                  {
                    path:'/brinfo',
                    name:'BRInfo',
                    component:BRInfo
                  },
                  {
                    path:'/searchbook',
                    name:'SearchBook',
                    component:SearchBook
                  },
                  {
                    path:'/systemmanager',
                    name:'SystemManager',
                    component: SystemManager
                  }
          
    ]
})