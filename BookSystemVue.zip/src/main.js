import Vue from 'vue'
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css'
import axios from 'axios'
import App from './App.vue'
//import VueRouter from 'vue-router';
import router from './router'
import store from './store';


Vue.config.productionTip = false
//将axios绑定到Vue原型上：
Vue.prototype.$http = axios
Vue.use(ElementUI);


new Vue({
  render: h => h(App),
  router: router,
  store: store
}).$mount('#app')
