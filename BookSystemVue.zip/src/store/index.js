import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex);
const actions = {};
const mutations = {
    SYNUSERINFO(state,value){
        state.user=value;
    }
};

const state={
    user:{},
};
const getters={
    userInfo(state){
        return state.user
    }
}

export default new Vuex.Store({
    state,
    actions, 
    mutations,
    getters
})